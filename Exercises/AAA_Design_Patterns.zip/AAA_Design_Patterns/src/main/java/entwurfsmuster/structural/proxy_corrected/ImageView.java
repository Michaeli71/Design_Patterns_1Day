package entwurfsmuster.structural.proxy_corrected;

import java.awt.Graphics;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public interface ImageView
{
    void display(Graphics g);
}