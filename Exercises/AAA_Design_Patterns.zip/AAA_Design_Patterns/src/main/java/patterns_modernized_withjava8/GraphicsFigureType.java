package patterns_modernized_withjava8;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public enum GraphicsFigureType {
    LINE, RECT, CIRCLE
}