package patterns_modernized_withjava8;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Rect implements GraphicObject
{
    int x;
    int y;
    
    public Rect(int x, int y)
    {
        this.x = x;
        this.y = y;        
    }
    
    @Override
    public void draw()
    {
        // TODO Auto-generated method stub

    }
}
/*
public record Rect(int x, int y) implements GraphicObject
{
    @Override
    public void draw()
    {
        // TODO Auto-generated method stub

    }
}
*/
